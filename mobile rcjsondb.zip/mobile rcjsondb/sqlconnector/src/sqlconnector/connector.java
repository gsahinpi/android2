package sqlconnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mysql.jdbc.PreparedStatement;


public class connector {
	
	Connection  con=null;
	String  url="jdbc:mysql://127.0.0.1/startrek";	
	public connector()
	{
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection(url, "myblog", "1234");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}//cons
	
	ArrayList <dataBaseObjects> gettitles()
	{
		ArrayList <dataBaseObjects>  returnlist;
		returnlist = new ArrayList<dataBaseObjects>();
		ResultSet rs=null;
		Statement smt=null;
		try {
			smt=con.createStatement();
			rs=smt.executeQuery("Select * from first");
			while (rs.next())
			{
		dataBaseObjects c= new dataBaseObjects();
		c.setTopic(rs.getString("topic"));
		c.setContent(rs.getString("content"));
		
		c.setId(rs.getInt("id"));
		returnlist.add(c);
		
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return returnlist;
	}

	public void inseritem(String topic,String comment)
	{
		String tableName = "first";
		String template ="INSERT INTO first (topic,content) VALUES (?, ?)";
		
		
		 try {
			java.sql.PreparedStatement inserter = 
				        con.prepareStatement(template);
			
			inserter.setString(1, topic);
	        inserter.setString(2, comment);
	        inserter.executeUpdate();
	        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		connector mydb=new connector();
	//	mydb.inseritem("696", "Execute order 66");
		ArrayList<dataBaseObjects> dummy=mydb.gettitles();
		for (dataBaseObjects c: dummy)
		{
			System.out.println(c.getContent());
			System.out.println(" ----"+c.getTopic());
		}

	}

}
