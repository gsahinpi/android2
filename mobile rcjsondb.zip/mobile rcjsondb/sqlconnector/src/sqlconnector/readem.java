package sqlconnector;

import java.io.InputStreamReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class readem {

	public static void main(String[] args) {
		try{
            Reader reader = new InputStreamReader(new URL("http://localhost:8080/sqlconnector/oksan").openStream()); //Read the json output
            Gson gson = new GsonBuilder().create();
           dataBaseObjects[] obj = gson.fromJson(reader, dataBaseObjects[].class);
            System.out.println(obj);
            for (int i=0;i<obj.length;i++)
            	
            {
            	  System.out.println(obj[i].getContent());
            }
            
        }catch(Exception e){
            System.out.println(e);
        }
		

	}

}
