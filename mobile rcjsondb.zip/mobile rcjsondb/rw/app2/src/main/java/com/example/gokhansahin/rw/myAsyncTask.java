package com.example.gokhansahin.rw;

import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by gokhansahin on 26.12.2017.
 */

public class myAsyncTask extends AsyncTask <Void,Void,Void >{
ArrayList<Example> dbresult;



    RecyclerView my;
    MainActivity m;

    public myAsyncTask(RecyclerView myRecyle, MainActivity mainActivity) {
        dbresult=new ArrayList<Example>();
        my=myRecyle;
        m=mainActivity;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

  for (Example e: dbresult){

      Log.d("db",e.getTopic());

  }
   jsonListadapter  jsadapret= new jsonListadapter(m,dbresult);
        my.setAdapter(jsadapret);

    }

    @Override
    protected Void doInBackground(Void... voids) {
        Log.d("db","in backgraound");

        Reader reader = null; //Read the json output
        try {
            reader = new InputStreamReader(new URL("http://localhost:8080/sqlconnector/oksan").openStream());
            Gson gson = new GsonBuilder().create();
            Example [] obj = gson.fromJson(reader, Example[].class);

            for (int i=0;i<obj.length;i++)
            {
             dbresult.add(obj[i]);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }



        return null;
    }
}
