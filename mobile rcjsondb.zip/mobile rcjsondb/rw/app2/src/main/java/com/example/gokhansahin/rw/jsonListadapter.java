package com.example.gokhansahin.rw;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by gokhansahin on 26.12.2017.
 */



public class jsonListadapter extends RecyclerView.Adapter  {
    private final ArrayList<Example> jsonlist;
    private LayoutInflater mInflater;

    public jsonListadapter(Context con, ArrayList<Example> list) {
        jsonlist=list;
        mInflater = LayoutInflater.from(con);



    }//cons
    class WordViewHolder extends RecyclerView.ViewHolder
    {
        public  TextView topic;
        public TextView content;
        ArrayList <Example> list;
        jsonListadapter adap;
        public WordViewHolder(View itemView, jsonListadapter adap)
        {
            super(itemView);

            topic= itemView.findViewById(R.id.word);
            content=itemView.findViewById(R.id.editText);
            this.adap=adap;
        }
    }//wordvievholde
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View mItemView = mInflater.inflate(R.layout.words, parent, false);
        return new jsonListadapter.WordViewHolder(mItemView, this);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        String mCurrent = jsonlist.get(position).getTopic();
        ( (WordViewHolder)holder).topic.setText(mCurrent);
        String cont=jsonlist.get(position).getContent();
        ( (WordViewHolder)holder).content.setText(cont);
    }

    @Override
    public int getItemCount() {
        return  jsonlist.size();
    }



}
