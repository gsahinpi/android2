package com.example.gokhansahin.rw;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Created by gokhansahin on 20.12.2017.
 */

public class WordListAdapter extends RecyclerView.Adapter <WordListAdapter.WordViewHolder>{

    private final ArrayList<String> mWordList;
    private LayoutInflater mInflater;
    public WordListAdapter(Context con, ArrayList<String> list) {
        mWordList=list;
        mInflater = LayoutInflater.from(con);



    }

    class WordViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public final TextView wordItemView;
        final WordListAdapter mAdapter;

        public WordViewHolder(View itemView,WordListAdapter adap) {
            super(itemView);
            wordItemView=itemView.findViewById(R.id.word);
            mAdapter=adap;
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            int mPosition = getLayoutPosition();
            String element = mWordList.get(mPosition);
            mWordList.set(mPosition, "Clicked! " + element);
            mAdapter.notifyDataSetChanged();
        }
    }//wordviewholder

    @Override
    public WordListAdapter.WordViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View mItemView = mInflater.inflate(R.layout.words, parent, false);
        return new WordViewHolder(mItemView, this);
    }

    @Override
    public void onBindViewHolder(WordListAdapter.WordViewHolder holder, int position) {
        String mCurrent = mWordList.get(position);
        holder.wordItemView.setText(mCurrent);

    }

    @Override
    public int getItemCount() {
        return mWordList.size();

    }
}
