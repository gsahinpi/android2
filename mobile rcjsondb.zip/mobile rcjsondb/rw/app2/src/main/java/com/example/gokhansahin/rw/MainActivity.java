package com.example.gokhansahin.rw;

import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {
    private final ArrayList<String> mWordList = new ArrayList<>();
    private int mCount = 0;
 RecyclerView myRecyle;
 WordListAdapter wordadapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        for (int i = 0; i < 20; i++) {
            mWordList.add("Word " + mCount++);
            Log.d("WordList", mWordList.get(i));
        }//bind data
        myRecyle=(RecyclerView)findViewById(R.id.recyclerview);
        wordadapter=new WordListAdapter(this,mWordList);
        myRecyle.setAdapter(wordadapter);
        myRecyle.setLayoutManager(new LinearLayoutManager(this));

myAsyncTask mytask= (myAsyncTask) new myAsyncTask(myRecyle,this).execute();


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int wordListSize = mWordList.size();
                // Add a new word to the end of the wordList.
                mWordList.add("+ Word " + wordListSize);
                // Notify the adapter, that the data has changed so it can
                // update the RecyclerView to display the data.
                myRecyle.getAdapter().notifyItemInserted(wordListSize);
                // Scroll to the bottom.
                myRecyle.smoothScrollToPosition(wordListSize);

            }
        });

    }//on create

}
